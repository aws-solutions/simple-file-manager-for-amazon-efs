import boto3
import botocore
import os
import yaml
import json
import zipfile
from chalice import Chalice, ChaliceViewError, BadRequestError, UnauthorizedError, ForbiddenError, NotFoundError, ConflictError, TooManyRequestsError


# Misc global variables


app = Chalice(app_name='api')
efs_lambda = os.path.join(
    os.path.dirname(__file__), 'chalicelib', 'efs_lambda.py')

# AWS Clients

efs = boto3.client('efs')
serverless = boto3.client('lambda')
iam = boto3.client('iam')


# Helper functions


def format_filesystem_response(filesystem):
    owner_id = filesystem['OwnerId']
    filesystem_id = filesystem['FileSystemId']
    filesystem_arn = filesystem['FileSystemArn']
    lifecycle_state = filesystem['LifeCycleState']
    name = filesystem['Name']
    size_in_bytes = filesystem['SizeInBytes']
    creation_time = filesystem['CreationTime']

    new_filesystem_object = dict()

    new_filesystem_object["owner_id"] = owner_id
    new_filesystem_object["file_system_id"] = filesystem_id
    new_filesystem_object["file_system_arn"] = filesystem_arn
    new_filesystem_object["lifecycle_state"] = lifecycle_state
    new_filesystem_object["name"] = name
    new_filesystem_object["size_in_bytes"] = size_in_bytes
    new_filesystem_object["creation_time"] = creation_time

    return new_filesystem_object


def create_function_zip():
    # TODO: Should this be a unique name / path based on give filesystem?
    zip_path = "/tmp/lambda.zip"
    with zipfile.ZipFile(zip_path, 'w') as z:
        z.write(efs_lambda)
    with open(zip_path, 'rb') as f:
        code = f.read()
    return code


def create_function_role(filesystem_name):
    # TODO: This will need to be updated to allow actual operations
    basic_role = """
        Version: '2012-10-17'
        Statement:
            - Effect: Allow
              Principal: 
                Service: lambda.amazonaws.com
              Action: sts:AssumeRole
        """
    # TODO: Add try / except / else blocks and handle errors
    # lambda.awazonaws.com can assume this role.
    role_response = iam.create_role(RoleName='{filesystem}-manager-role'.format(filesystem=filesystem_name),
                    AssumeRolePolicyDocument=json.dumps(yaml.load(basic_role)))

    # This role has the AWSLambdaBasicExecutionRole managed policy.
    policy_response = iam.attach_role_policy(RoleName='{filesystem}-manager-policy'.format(filesystem=filesystem_name),
                           PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole')

    return role_response['Arn']


def create_function(filesystem_name, filesystem_arn, vpc):
    code = create_function_zip()
    arn = create_function_role(filesystem_name)
    try:
        response = serverless.create_function(
            FunctionName='{filesystem}-manager-lambda'.format(filesystem=filesystem_name),
            Runtime='python3.8',
            Role=arn,
            Handler='efs_lambda.lambda_handler',
            Code={
                'ZipFile': code
            },
            Description='Lambda function to process file manager operations for filesystem: {filesystem}'.format(filesystem=filesystem_name),
            Timeout=60,
            MemorySize=512,
            Publish=True,
            VpcConfig=vpc,
            # Environment={
            #     'Variables': {
            #         'string': 'string'
            #     }
            # },
            # Tags={
            #     'string': 'string'
            # },
            FileSystemConfigs=[
                {
                    'Arn': filesystem_arn,
                    'LocalMountPath': '/mnt/efs'
                },
            ]
        )
    except botocore.exceptions.ClientError as error:
        app.log.error(error)
        raise ChaliceViewError("Check API logs")
    else:
        return response

@app.route('/')
def index():
    return {'hello': 'world'}


@app.route('/upload', methods=["POST"], cors=True)
def upload():
    return None


@app.route('/filesystems', methods=["GET"], cors=True)
def describe_filesystems():
    try:
        response = efs.describe_file_systems()
    except botocore.exceptions.ClientError as error:
        app.log.error(error)
        raise ChaliceViewError("Check API logs")
    else:
        filesystems = response['FileSystems']
        formatted_filesystems = []
        for filesystem in filesystems:
            formatted = format_filesystem_response(filesystem)
            formatted_filesystems.append(formatted)
        return formatted_filesystems


@app.route('/filesystems/{filesystem_id}/netinfo', methods=['GET'], cors=True)
def get_netinfo_for_filesystem(filesystem_id):
    netinfo = []
    try:
        response = efs.describe_mount_targets(
            FileSystemId=filesystem_id
        )
    except botocore.exceptions.ClientError as error:
        app.log.debug(error)
        raise ChaliceViewError
    else:
        mount_targets = response['MountTargets']
        for target in mount_targets:
            mount_target_id = target['MountTargetId']
            try:
                response = efs.describe_mount_target_security_groups(
                    MountTargetId=mount_target_id
                )
            except botocore.exceptions.ClientError as error:
                app.log.debug(error)
                raise ChaliceViewError
            else:
                security_groups = response['SecurityGroups']
                vpc_item = {'{id}'.format(id=mount_target_id): {'security_groups': security_groups, 'vpc_id': target['VpcId'], 'az_id': target['AvailabilityZoneId'], 'subnet_id': target['SubnetId']}}
                netinfo.append(vpc_item)

    return netinfo


@app.route('/filesystems/{filesystem_id}/lambda', methods=['POST'], cors=True)
def create_filesystem_lambda():
    request = app.current_request
    json_body = request.json_body

    try:
        subnet_id = json_body['subnetId']
        security_groups = json_body['securityGroups']
        filesystem_arn = json_body['filesystemArn']
        name = json_body['name']
    except KeyError as error:
        app.log.debug(error)
        raise BadRequestError("Check API logs")
    else:
        vpc_config = {
            'SubnetIds': [
                subnet_id,
            ],
            'SecurityGroupIds': security_groups
        }

    try:
        response = create_function(name, filesystem_arn, vpc_config)
    except Exception as error:
        app.log.debug(error)
        raise ChaliceViewError('Check API Logs')
    else:
        return response


# The view function above will return {"hello": "world"}
# whenever you make an HTTP GET request to '/'.
#
# Here are a few more examples:
#
# @app.route('/hello/{name}')
# def hello_name(name):
#    # '/hello/james' -> {"hello": "james"}
#    return {'hello': name}
#
# @app.route('/users', methods=['POST'])
# def create_user():
#     # This is the JSON body the user sent in their POST request.
#     user_as_json = app.current_request.json_body
#     # We'll echo the json body back to the user in a 'user' key.
#     return {'user': user_as_json}
#
# See the README documentation for more examples.
#
