from os import walk
# File manager operation events:
# list: {"operation": "list", "path": "$dir"}
# upload: {"operation": "upload", "path": "$dir", "filename": "$name", "payload": "$binary"}


def modify(event):
    return None


def delete(event):
    return None


def upload(event):
    return None


def list(event):
    # get path to list
    try:
        path = event['path']
    except KeyError:
        raise Exception('Missing required parameter in event: "path"')

    try:
        dir_items = []
        file_items = []
        for (dirpath, dirnames, filenames) in walk(path):
            dir_items.extend(dirnames)
            file_items.extend(filenames)
            break
    # TODO: narrower exception scope and proper debug output
    except Exception as error:
        print(error)
        raise Exception(error)
    else:
        return {"path": path, "directiories": dir_items, "files": file_items}


def lambda_handler(event, context):
    # get operation type
    try:
        operation_type = event['operation']
    except KeyError:
        raise Exception('Missing required parameter in event: "operation"')
    else:
        if operation_type == 'upload':
            upload(event)
        if operation_type == 'list':
            list_result = list(event)
            return list_result
        if operation_type == 'modify':
            modify(event)
        if operation_type == 'delete':
            delete(event)
